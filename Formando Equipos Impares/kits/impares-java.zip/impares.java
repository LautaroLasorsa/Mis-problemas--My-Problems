import java.lang.*;
import java.util.*;

public class impares {
    public static int impares(ArrayList<ArrayList<Integer>> subordinados) {
        // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    }
}
